package ir.hafteh.app

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class Task(val title: String, val rank: Int, val hour: Int, val minute: Int)
private val rankColors = listOf(Color(0xFF78909C), Color(0xFF1976D2), Color(0xFFEF6C00), Color(0xFFC62828), Color(0xFF6A1B9A))
private val faLocale = Locale("fa", "IR")
private fun dateKey(c: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
private fun readable(c: Calendar) = SimpleDateFormat("EEEE  yyyy/MM/dd", faLocale).format(c.time)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HaftehApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HaftehApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("hafteh_data", 0) }
    val schedules = remember {
        mutableStateMapOf<String, MutableList<Task>>().apply {
            val raw = prefs.getString("schedules", "{}") ?: "{}"
            runCatching {
                val obj = JSONObject(raw)
                obj.keys().forEach { key ->
                    val arr = obj.getJSONArray(key)
                    this[key] = MutableList(arr.length()) { i ->
                        val t = arr.getJSONObject(i)
                        Task(t.optString("title"), t.optInt("rank"), t.optInt("hour", 9), t.optInt("minute"))
                    }
                }
            }
        }
    }
    var selectedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var newTitle by remember { mutableStateOf("") }
    var newRank by remember { mutableIntStateOf(2) }
    var newHour by remember { mutableIntStateOf(9) }
    var newMinute by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var showCopy by remember { mutableStateOf(false) }
    var copyMode by remember { mutableIntStateOf(0) }
    var copyTarget by remember { mutableStateOf(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }) }
    val key = dateKey(selectedDate)
    val tasks = schedules[key] ?: emptyList()

    fun persist() {
        val obj = JSONObject()
        schedules.forEach { (k, list) ->
            val arr = JSONArray()
            list.forEach { t ->
                arr.put(JSONObject().put("title", t.title).put("rank", t.rank).put("hour", t.hour).put("minute", t.minute))
            }
            obj.put(k, arr)
        }
        prefs.edit().putString("schedules", obj.toString()).apply()
    }
    fun pickDate(initial: Calendar, onPicked: (Calendar) -> Unit) {
        DatePickerDialog(context, { _, y, m, d ->
            onPicked((initial.clone() as Calendar).apply { set(y, m, d) })
        }, initial.get(Calendar.YEAR), initial.get(Calendar.MONTH), initial.get(Calendar.DAY_OF_MONTH)).show()
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(topBar = {
            TopAppBar(title = { Text("برنامه‌ریز هفته") }, actions = {
                TextButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) {
                    Text(if (dark) "حالت روز" else "حالت شب")
                }
            })
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { selectedDate = (selectedDate.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) } }) { Text("روز قبل") }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(readable(selectedDate), style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { pickDate(selectedDate) { selectedDate = it } }) { Text("انتخاب تاریخ") }
                    }
                    TextButton(onClick = { selectedDate = (selectedDate.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) } }) { Text("روز بعد") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { selectedDate = Calendar.getInstance() }, modifier = Modifier.weight(1f)) { Text("امروز") }
                    OutlinedButton(onClick = { showCopy = true; copyTarget = (selectedDate.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) } }, modifier = Modifier.weight(1f)) { Text("کپی برنامه") }
                }
                HorizontalDivider()
                Text("افزودن برنامه", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("عنوان برنامه") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("رتبه اهمیت")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    (1..5).forEach { rank ->
                        val selected = newRank == rank
                        Button(onClick = { newRank = rank }, colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) rankColors[rank-1] else rankColors[rank-1].copy(alpha = .48f)
                        ), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp), modifier = Modifier.weight(1f)) {
                            Text("$rank", color = Color.White)
                        }
                    }
                }
                Text("ساعت شروع")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                    NumberStepper("ساعت", newHour, 0, 23) { newHour = it }
                    Text(" : ", style = MaterialTheme.typography.headlineSmall)
                    NumberStepper("دقیقه", newMinute, 0, 59) { newMinute = it }
                }
                Button(onClick = {
                    if (newTitle.isNotBlank()) {
                        val list = (schedules[key] ?: mutableListOf()).toMutableList()
                        list.add(Task(newTitle.trim(), newRank, newHour, newMinute))
                        schedules[key] = list.sortedWith(compareBy<Task> { it.hour }.thenBy { it.minute }).toMutableList()
                        newTitle = ""; persist(); message = "برنامه ذخیره شد"
                    } else message = "عنوان برنامه را وارد کن"
                }, modifier = Modifier.fillMaxWidth()) { Text("ثبت برنامه") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider()
                Text("برنامه‌های این روز (${tasks.size})", style = MaterialTheme.typography.titleMedium)
                if (tasks.isEmpty()) Text("برای این تاریخ برنامه‌ای ثبت نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f, fill = false)) {
                    items(tasks.toList()) { task ->
                        Card {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).background(rankColors[(task.rank-1).coerceIn(0,4)], RoundedCornerShape(50)))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(task.title, style = MaterialTheme.typography.titleMedium)
                                    Text("رتبه ${task.rank}  •  %02d:%02d".format(task.hour, task.minute), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = {
                                    schedules[key] = (schedules[key] ?: mutableListOf()).toMutableList().also { it.remove(task) }
                                    persist()
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
                Text("اطلاعات برنامه روی همین گوشی ذخیره می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (showCopy) {
            AlertDialog(onDismissRequest = { showCopy = false }, title = { Text("کپی برنامه به تاریخ دیگر") }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مقصد: ${readable(copyTarget)}")
                    OutlinedButton(onClick = { pickDate(copyTarget) { copyTarget = it } }) { Text("انتخاب تاریخ مقصد") }
                    Text("نوع کپی")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = copyMode == 0, onClick = { copyMode = 0 }); Text("کپی کامل برنامه‌ها")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = copyMode == 1, onClick = { copyMode = 1 }); Text("فقط کپی زمان‌بندی")
                    }
                }
            }, confirmButton = {
                TextButton(onClick = {
                    val source = schedules[key].orEmpty()
                    val targetKey = dateKey(copyTarget)
                    val existing = (schedules[targetKey] ?: mutableListOf()).toMutableList()
                    if (copyMode == 0) schedules[targetKey] = source.toMutableList()
                    else {
                        val count = minOf(source.size, existing.size)
                        for (i in 0 until count) existing[i] = existing[i].copy(hour = source[i].hour, minute = source[i].minute)
                        schedules[targetKey] = existing
                    }
                    persist(); showCopy = false
                    message = if (copyMode == 0) "برنامه‌ها کپی شدند" else "زمان‌بندی موارد موجود کپی شد"
                }) { Text("انجام کپی") }
            }, dismissButton = { TextButton(onClick = { showCopy = false }) { Text("انصراف") } })
        }
    }
}

@Composable
private fun NumberStepper(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = { onChange(if (value >= max) min else value + 1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+") }
            Text("%02d".format(value), modifier = Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.headlineSmall)
            FilledTonalButton(onClick = { onChange(if (value <= min) max else value - 1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("−") }
        }
    }
}
