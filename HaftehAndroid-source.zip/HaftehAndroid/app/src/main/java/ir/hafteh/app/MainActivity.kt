package ir.hafteh.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Ink=Color(0xFF25243A); private val Muted=Color(0xFF858397); private val Canvas=Color(0xFFF8F7F4); private val Purple=Color(0xFF7569CF)
private val Pastels=listOf(Color(0xFFE9E4FA),Color(0xFFFFE8C9),Color(0xFFDDF0D8),Color(0xFFDCEAF8),Color(0xFFF7DEDF),Color(0xFFE9EED6))
private val Days=listOf("شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه")
data class PlanItem(val id:String=UUID.randomUUID().toString(),val title:String,val day:Int,val start:String,val end:String,val color:Int)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{HaftehApp(this)}}}

@Composable fun HaftehApp(context:Context){
 val prefs=remember{context.getSharedPreferences("hafteh",Context.MODE_PRIVATE)}
 var plans by remember{mutableStateOf(loadPlans(prefs))}; var selectedDay by remember{mutableIntStateOf(0)}; var showEditor by remember{mutableStateOf(false)}; var editing by remember{mutableStateOf<PlanItem?>(null)}; var page by remember{mutableIntStateOf(0)}
 fun persist(list:List<PlanItem>){plans=list;savePlans(prefs,list)}
 MaterialTheme(colorScheme=lightColorScheme(primary=Purple,background=Canvas,surface=Color.White)){
  Scaffold(containerColor=Canvas,floatingActionButton={FloatingActionButton(onClick={editing=null;showEditor=true},containerColor=Purple,contentColor=Color.White,shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.Add,"افزودن")}},bottomBar={NavigationBar(containerColor=Color.White){NavigationBarItem(page==0,{page=0},{Icon(Icons.Default.CalendarMonth,null)},label={Text("برنامه هفتگی")});NavigationBarItem(page==1,{page=1},{Icon(Icons.Default.CheckCircle,null)},label={Text("فعالیت‌ها")});NavigationBarItem(page==2,{page=2},{Icon(Icons.Default.Schedule,null)},label={Text("گزارش زمان")})}}){pad->
   Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)){
    Row(Modifier.fillMaxWidth().padding(top=18.dp,bottom=15.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("سلام! وقتت رو بساز",color=Muted,fontSize=12.sp);Text("برنامه‌ریز هفته",color=Ink,fontSize=24.sp,fontWeight=FontWeight.ExtraBold)};Box(Modifier.size(46.dp).background(Color(0xFFECE9FA),CircleShape),contentAlignment=Alignment.Center){Text("ه",color=Purple,fontSize=22.sp,fontWeight=FontWeight.Bold)}}
    when(page){0->{Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){Days.forEachIndexed{i,d->val active=selectedDay==i;Column(Modifier.width(49.dp).background(if(active)Purple else Color.White,RoundedCornerShape(15.dp)).clickable{selectedDay=i}.padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(d.take(2),color=if(active)Color.White else Muted,fontSize=11.sp);Text("${i+1}",color=if(active)Color.White else Ink,fontWeight=FontWeight.Bold,fontSize=17.sp)}}}
     val mins=plans.sumOf{duration(it.start,it.end)};Row(Modifier.fillMaxWidth().padding(top=15.dp).background(Color(0xFFEDEAFB),RoundedCornerShape(18.dp)).padding(15.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("این هفته در یک نگاه",color=Ink,fontWeight=FontWeight.Bold);Text("قدم‌های کوچک، نتیجه‌های بزرگ",color=Muted,fontSize=11.sp)};Column(horizontalAlignment=Alignment.End){Text("${plans.size} فعالیت",color=Purple,fontWeight=FontWeight.Bold);Text("${mins/60} ساعت برنامه",color=Muted,fontSize=11.sp)}}
     Text("نمای هفتگی",color=Ink,fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=20.dp,bottom=10.dp)); WeeklyBoard(plans, { d -> selectedDay=d }, { p -> editing=p;showEditor=true }, { p -> persist(plans.filterNot{it.id==p.id}) })
    }
    1->{Text("همه فعالیت‌ها",color=Ink,fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=16.dp));if(plans.isEmpty())EmptyState() else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){items(plans.sortedWith(compareBy<PlanItem>{it.day}.thenBy{it.start}), key = { it.id }){p->PlanRow(p,true,{editing=p;showEditor=true},{persist(plans.filterNot{it.id==p.id})})}}}
    else->{val total=plans.sumOf{duration(it.start,it.end)};Text("گزارش زمان",color=Ink,fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=18.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){StatTile("مجموع زمان","${total/60} ساعت و ${total%60} دقیقه",Modifier.weight(1f));StatTile("تعداد فعالیت","${plans.size}",Modifier.weight(1f))};Text("تقسیم برنامه در روزهای هفته",color=Ink,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=24.dp,bottom=10.dp));Days.forEachIndexed{i,d->val m=plans.filter{it.day==i}.sumOf{duration(it.start,it.end)};Column(Modifier.fillMaxWidth().padding(vertical=7.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(d,color=Ink,fontSize=13.sp);Text("${m/60} ساعت و ${m%60} دقیقه",color=Muted,fontSize=12.sp)};Box(Modifier.fillMaxWidth().padding(top=6.dp).height(7.dp).background(Color(0xFFE9E7EF),CircleShape)){Box(Modifier.fillMaxWidth((m/600f).coerceIn(0f,1f)).fillMaxHeight().background(Purple,CircleShape))}}}}
   }
  }
  }
 }
 if(showEditor)PlanEditor(editing,{showEditor=false}){item->val overlap=plans.any{old->old.id!=item.id&&old.day==item.day&&item.start<old.end&&item.end>old.start};if(!overlap){val list=if(plans.any{it.id==item.id})plans.map{if(it.id==item.id)item else it}else plans+item;persist(list);selectedDay=item.day;showEditor=false};overlap}
}

@Composable private fun WeeklyBoard(plans:List<PlanItem>,onDay:(Int)->Unit,onEdit:(PlanItem)->Unit,onDelete:(PlanItem)->Unit){
 Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).weight(1f),horizontalArrangement=Arrangement.spacedBy(9.dp)){
  Days.forEachIndexed{index,day->
   Column(Modifier.width(142.dp).fillMaxHeight().background(Color.White,RoundedCornerShape(15.dp)).padding(9.dp)){
    Text(day,color=Purple,fontWeight=FontWeight.Bold,fontSize=14.sp,modifier=Modifier.fillMaxWidth().clickable{onDay(index)},textAlign=androidx.compose.ui.text.style.TextAlign.Center)
    HorizontalDivider(color=Color(0xFFEDEBF2),modifier=Modifier.padding(vertical=7.dp))
    val dayPlans=plans.filter{it.day==index}.sortedBy{it.start}
    if(dayPlans.isEmpty()) Text("خالی",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=8.dp).align(Alignment.CenterHorizontally))
    dayPlans.forEach{p->
     Column(Modifier.fillMaxWidth().padding(bottom=7.dp).background(Pastels[p.color.coerceIn(0,5)],RoundedCornerShape(9.dp)).clickable{onEdit(p)}.padding(8.dp)){
      Text(p.title,color=Ink,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
      Text("${p.start}–${p.end}",color=Ink.copy(alpha=.72f),fontSize=10.sp,modifier=Modifier.padding(top=4.dp))
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){Text("حذف",color=Color(0xFF9A5555),fontSize=10.sp,modifier=Modifier.clickable{onDelete(p)})}
     }
    }
   }
  }
 }
}

@Composable private fun EmptyState(){Box(Modifier.fillMaxWidth().height(260.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("هنوز برنامه‌ای ثبت نکرده‌ای",color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp);Text("برای شروع، دکمه + را بزن",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=7.dp))}}}
@Composable private fun PlanRow(p:PlanItem,showDay:Boolean,onEdit:()->Unit,onDelete:()->Unit){Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(15.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.width(5.dp).height(48.dp).background(Pastels[p.color.coerceIn(0,5)],RoundedCornerShape(5.dp)));Column(Modifier.weight(1f).padding(start=11.dp)){Text(p.title,color=Ink,fontWeight=FontWeight.SemiBold,fontSize=14.sp);Text("${p.start} تا ${p.end}"+(if(showDay)" • ${Days[p.day]}" else ""),color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))};IconButton(onClick=onEdit){Icon(Icons.Default.Edit,"ویرایش",tint=Muted)};IconButton(onClick=onDelete){Icon(Icons.Default.DeleteOutline,"حذف",tint=Color(0xFFCB7777))}}}
@Composable private fun StatTile(label:String,value:String,modifier:Modifier){Column(modifier.background(Color.White,RoundedCornerShape(16.dp)).padding(14.dp)){Text(label,color=Muted,fontSize=12.sp);Text(value,color=Ink,fontSize=14.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun PlanEditor(existing:PlanItem?,dismiss:()->Unit,save:(PlanItem)->Boolean){var title by remember{mutableStateOf(existing?.title?:"")};var day by remember{mutableIntStateOf(existing?.day?:0)};var start by remember{mutableStateOf(existing?.start?:"09:00")};var end by remember{mutableStateOf(existing?.end?:"10:00")};var color by remember{mutableIntStateOf(existing?.color?:0)};var error by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=dismiss,title={Text(if(existing==null)"افزودن برنامه" else "ویرایش برنامه",fontWeight=FontWeight.Bold)},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){OutlinedTextField(title,{title=it;error=""},label={Text("عنوان فعالیت")},singleLine=true);Text("روز هفته",color=Muted,fontSize=12.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){Days.forEachIndexed{i,d->FilterChip(day==i,{day=i},label={Text(d)})}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(start,{start=it},label={Text("شروع")},modifier=Modifier.weight(1f),singleLine=true);OutlinedTextField(end,{end=it},label={Text("پایان")},modifier=Modifier.weight(1f),singleLine=true)};Text("رنگ فعالیت",color=Muted,fontSize=12.sp);Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Pastels.forEachIndexed{i,c->Box(Modifier.size(30.dp).background(c,CircleShape).border(if(color==i)2.dp else 0.dp,if(color==i)Purple else c,CircleShape).clickable{color=i})}};if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)}},confirmButton={TextButton(onClick={val s=parse(start);val e=parse(end);if(title.isBlank())error="عنوان فعالیت را وارد کن" else if(s==null||e==null||e<=s)error="ساعت را به شکل 09:00 وارد کن" else if(save(PlanItem(existing?.id?:UUID.randomUUID().toString(),title.trim(),day,start,end,color)))error="این بازه با برنامه دیگری تداخل دارد"}){Text("ذخیره")}},dismissButton={TextButton(onClick=dismiss){Text("انصراف")}})
}
private fun parse(s:String):Int?=try{val p=s.trim().split(":");if(p.size!=2)null else{val h=p[0].toInt();val m=p[1].toInt();if(h !in 0..23||m !in 0..59)null else h*60+m}}catch(_:Exception){null}
private fun duration(s:String,e:String)=((parse(e)?:0)-(parse(s)?:0)).coerceAtLeast(0)
private fun loadPlans(p:android.content.SharedPreferences):List<PlanItem>{val raw=p.getString("items",null)?:return emptyList();return try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);PlanItem(o.getString("id"),o.getString("title"),o.getInt("day"),o.getString("start"),o.getString("end"),o.getInt("color"))}}catch(_:Exception){emptyList()}}
private fun savePlans(p:android.content.SharedPreferences,list:List<PlanItem>){val a=JSONArray();list.forEach{a.put(JSONObject().put("id",it.id).put("title",it.title).put("day",it.day).put("start",it.start).put("end",it.end).put("color",it.color))};p.edit().putString("items",a.toString()).apply()}
